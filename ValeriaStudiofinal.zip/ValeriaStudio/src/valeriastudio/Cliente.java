package valeriastudio;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class Cliente {
    private String nombre;
    private String celular;
    private LocalDate fechaCumpleanos;
    private String comoConocioNegocio;
    private String observaciones;
    private int totalVisitas;
    private double totalGastado;
    private LocalDate ultimaVisita;

    public Cliente() {
        this.nombre = "";
        this.celular = "";
        this.fechaCumpleanos = null;
        this.comoConocioNegocio = "";
        this.observaciones = "";
        this.totalVisitas = 0;
        this.totalGastado = 0.0;
        this.ultimaVisita = null;
    }

    public Cliente(String nombre, String celular, LocalDate fechaCumpleanos,
                   String comoConocioNegocio, String observaciones) {
        this.nombre = nombre;
        this.celular = celular;
        this.fechaCumpleanos = fechaCumpleanos;
        this.comoConocioNegocio = comoConocioNegocio;
        this.observaciones = observaciones;
        this.totalVisitas = 0;
        this.totalGastado = 0.0;
        this.ultimaVisita = null;
    }

    public void registrarVisita(double monto, LocalDate fecha) {
        this.totalVisitas++;
        this.totalGastado += monto;
        this.ultimaVisita = fecha;
    }

    public String generarMensajeRecordatorio(LocalDate fecha, LocalTime hora) {
        DateTimeFormatter fmtFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter fmtHora = DateTimeFormatter.ofPattern("hh:mm a");
        return "Hola linda " + nombre + ", te recordamos que tienes tu cita en "
                + "Valeria Guerrero Studio el " + fecha.format(fmtFecha)
                + " a las " + hora.format(fmtHora) + ". ¡Te esperamos con todo el amor!";
    }

    public boolean esCumpleanos(LocalDate hoy) {
        return fechaCumpleanos != null
                && fechaCumpleanos.getDayOfMonth() == hoy.getDayOfMonth()
                && fechaCumpleanos.getMonth() == hoy.getMonth();
    }

    @Override
    public String toString() {
        return nombre + " | Cel: " + celular + " | Visitas: " + totalVisitas
                + " | Total gastado: $" + String.format("%,.0f", totalGastado)
                + (observaciones.isEmpty() ? "" : " | Obs: " + observaciones);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public LocalDate getFechaCumpleanos() {
        return fechaCumpleanos;
    }

    public void setFechaCumpleanos(LocalDate fechaCumpleanos) {
        this.fechaCumpleanos = fechaCumpleanos;
    }

    public String getComoConocioNegocio() {
        return comoConocioNegocio;
    }

    public void setComoConocioNegocio(String comoConocioNegocio) {
        this.comoConocioNegocio = comoConocioNegocio;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public int getTotalVisitas() {
        return totalVisitas;
    }

    public void setTotalVisitas(int totalVisitas) {
        this.totalVisitas = totalVisitas;
    }

    public double getTotalGastado() {
        return totalGastado;
    }

    public void setTotalGastado(double totalGastado) {
        this.totalGastado = totalGastado;
    }

    public LocalDate getUltimaVisita() {
        return ultimaVisita;
    }

    public void setUltimaVisita(LocalDate ultimaVisita) {
        this.ultimaVisita = ultimaVisita;
    }
}
