package valeriastudio;

import java.time.LocalDate;
import java.time.LocalTime;

public class Negocio {
    private String nombre;
    private String propietaria;
    private Cliente[] clientes;
    private TratamientoEstetico[] tratamientos;
    private Cita[] citas;
    private Pago[] pagos;
    private int numClientes;
    private int numTratamientos;
    private int numCitas;
    private int numPagos;

    public Negocio() {
        this.nombre = "";
        this.propietaria = "";
        this.clientes = new Cliente[100];
        this.tratamientos = new TratamientoEstetico[50];
        this.citas = new Cita[500];
        this.pagos = new Pago[500];
        this.numClientes = 0;
        this.numTratamientos = 0;
        this.numCitas = 0;
        this.numPagos = 0;
    }

    public Negocio(String nombre, String propietaria, int capacidadClientes,
                   int capacidadTratamientos, int capacidadCitas, int capacidadPagos) {
        this.nombre = nombre;
        this.propietaria = propietaria;
        this.clientes = new Cliente[capacidadClientes];
        this.tratamientos = new TratamientoEstetico[capacidadTratamientos];
        this.citas = new Cita[capacidadCitas];
        this.pagos = new Pago[capacidadPagos];
        this.numClientes = 0;
        this.numTratamientos = 0;
        this.numCitas = 0;
        this.numPagos = 0;
    }

    public boolean agregarCliente(Cliente cliente) {
        if (numClientes >= clientes.length) return false;
        clientes[numClientes] = cliente;
        numClientes++;
        return true;
    }

    public Cliente buscarCliente(String nombre) {
        for (int i = 0; i < numClientes; i++) {
            if (clientes[i].getNombre().equalsIgnoreCase(nombre)) {
                return clientes[i];
            }
        }
        return null;
    }

    public boolean agregarTratamiento(TratamientoEstetico tratamiento) {
        if (numTratamientos >= tratamientos.length) return false;
        tratamientos[numTratamientos] = tratamiento;
        numTratamientos++;
        return true;
    }

    public TratamientoEstetico buscarTratamiento(String nombre) {
        for (int i = 0; i < numTratamientos; i++) {
            if (tratamientos[i].getNombre().equalsIgnoreCase(nombre)) {
                return tratamientos[i];
            }
        }
        return null;
    }

    public void mostrarCatalogo() {
        System.out.println("---- Catálogo de tratamientos ----");
        for (int i = 0; i < numTratamientos; i++) {
            System.out.println((i + 1) + ". " + tratamientos[i].getDescripcion());
        }
    }

    public boolean hayDisponibilidad(Cita nueva) {
        for (int i = 0; i < numCitas; i++) {
            if (citas[i].seCruzaCon(nueva.getFecha(), nueva.getHoraInicio(), nueva.getHoraFin())) {
                return false;
            }
        }
        return true;
    }

    public boolean agendarCita(Cita cita) {
        if (numCitas >= citas.length || !hayDisponibilidad(cita)) {
            return false;
        }
        citas[numCitas] = cita;
        numCitas++;
        return true;
    }

    public void consultarAgenda(LocalDate fecha) {
        System.out.println("---- Agenda del " + fecha + " ----");
        boolean hay = false;
        for (int i = 0; i < numCitas; i++) {
            if (citas[i].getFecha().equals(fecha)) {
                System.out.println(citas[i]);
                hay = true;
            }
        }
        if (!hay) System.out.println("No hay citas para este día.");
    }

    public boolean registrarPago(Pago pago) {
        if (numPagos >= pagos.length) return false;
        pagos[numPagos] = pago;
        numPagos++;
        return true;
    }

    public boolean completarCitaYCobrar(Cita cita, String metodoPago) {
        if (!cita.getEstado().equals(Cita.CONFIRMADA)) return false;
        cita.completar();
        return registrarPago(new Pago(cita, metodoPago));
    }

    public boolean registrarGasto(double monto, String metodoPago, LocalDate fecha, String descripcion) {
        return registrarPago(new Pago(monto, metodoPago, fecha, descripcion));
    }

    public double calcularTotalIngresos() {
        double total = 0;
        for (int i = 0; i < numPagos; i++) {
            if (pagos[i].esIngreso()) total += pagos[i].getMonto();
        }
        return total;
    }

    public double calcularTotalGastos() {
        double total = 0;
        for (int i = 0; i < numPagos; i++) {
            if (pagos[i].esGasto()) total += pagos[i].getMonto();
        }
        return total;
    }

    public double calcularGananciaNeta() {
        return calcularTotalIngresos() - calcularTotalGastos();
    }

    public int contarInasistencias() {
        int contador = 0;
        for (int i = 0; i < numCitas; i++) {
            if (citas[i].getEstado().equals(Cita.NO_LLEGO)) contador++;
        }
        return contador;
    }

    public void mostrarResumenFinanciero() {
        System.out.println("====== RESUMEN " + nombre.toUpperCase() + " ======");
        System.out.println("Total ingresos:   $" + String.format("%,.0f", calcularTotalIngresos()));
        System.out.println("Total gastos:     $" + String.format("%,.0f", calcularTotalGastos()));
        System.out.println("Ganancia neta:    $" + String.format("%,.0f", calcularGananciaNeta()));
        System.out.println("Clientas:         " + numClientes);
        System.out.println("Citas totales:    " + numCitas);
        System.out.println("Inasistencias:    " + contarInasistencias());
    }

    public void mostrarRecordatorios(LocalDate hoy) {
        LocalDate manana = hoy.plusDays(1);
        boolean hay = false;
        System.out.println("---- Recordatorios pendientes ----");
        for (int i = 0; i < numCitas; i++) {
            Cita c = citas[i];
            boolean enRango = c.getFecha().equals(hoy) || c.getFecha().equals(manana);
            if (enRango && c.getEstado().equals(Cita.CONFIRMADA)) {
                System.out.println("Para " + c.getCliente().getCelular() + ":");
                System.out.println("  " + c.getCliente().generarMensajeRecordatorio(c.getFecha(), c.getHoraInicio()));
                hay = true;
            }
        }
        if (!hay) System.out.println("No hay recordatorios pendientes.");
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPropietaria() {
        return propietaria;
    }

    public void setPropietaria(String propietaria) {
        this.propietaria = propietaria;
    }

    public Cliente[] getClientes() {
        return clientes;
    }

    public void setClientes(Cliente[] clientes) {
        this.clientes = clientes;
    }

    public TratamientoEstetico[] getTratamientos() {
        return tratamientos;
    }

    public void setTratamientos(TratamientoEstetico[] tratamientos) {
        this.tratamientos = tratamientos;
    }

    public Cita[] getCitas() {
        return citas;
    }

    public void setCitas(Cita[] citas) {
        this.citas = citas;
    }

    public Pago[] getPagos() {
        return pagos;
    }

    public void setPagos(Pago[] pagos) {
        this.pagos = pagos;
    }

    public int getNumClientes() {
        return numClientes;
    }

    public void setNumClientes(int numClientes) {
        this.numClientes = numClientes;
    }

    public int getNumTratamientos() {
        return numTratamientos;
    }

    public void setNumTratamientos(int numTratamientos) {
        this.numTratamientos = numTratamientos;
    }

    public int getNumCitas() {
        return numCitas;
    }

    public void setNumCitas(int numCitas) {
        this.numCitas = numCitas;
    }

    public int getNumPagos() {
        return numPagos;
    }

    public void setNumPagos(int numPagos) {
        this.numPagos = numPagos;
    }
}
