package valeriastudio;

import java.time.LocalTime;

public class TratamientoEstetico {
    private String nombre;
    private String tipo;
    private double precio;
    private int duracionMinutos;
    private boolean requiereRetoque;
    private int diasEntreRetoques;

    public TratamientoEstetico() {
        this.nombre = "";
        this.tipo = "";
        this.precio = 0.0;
        this.duracionMinutos = 0;
        this.requiereRetoque = false;
        this.diasEntreRetoques = 0;
    }

    public TratamientoEstetico(String nombre, String tipo, double precio, int duracionMinutos) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.precio = precio;
        this.duracionMinutos = duracionMinutos;
        this.requiereRetoque = false;
        this.diasEntreRetoques = 0;
    }

    public TratamientoEstetico(String nombre, String tipo, double precio, int duracionMinutos,
                               int diasEntreRetoques) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.precio = precio;
        this.duracionMinutos = duracionMinutos;
        this.requiereRetoque = true;
        this.diasEntreRetoques = diasEntreRetoques;
    }

    public LocalTime calcularHoraFin(LocalTime horaInicio) {
        return horaInicio.plusMinutes(duracionMinutos);
    }

    public String getDescripcion() {
        String texto = nombre + " (" + tipo + ") - $" + String.format("%,.0f", precio)
                + " - " + duracionMinutos + " min";
        if (requiereRetoque) {
            texto += " - retoque cada " + diasEntreRetoques + " días";
        }
        return texto;
    }

    @Override
    public String toString() {
        return getDescripcion();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getDuracionMinutos() {
        return duracionMinutos;
    }

    public void setDuracionMinutos(int duracionMinutos) {
        this.duracionMinutos = duracionMinutos;
    }

    public boolean isRequiereRetoque() {
        return requiereRetoque;
    }

    public void setRequiereRetoque(boolean requiereRetoque) {
        this.requiereRetoque = requiereRetoque;
    }

    public int getDiasEntreRetoques() {
        return diasEntreRetoques;
    }

    public void setDiasEntreRetoques(int diasEntreRetoques) {
        this.diasEntreRetoques = diasEntreRetoques;
    }
}
