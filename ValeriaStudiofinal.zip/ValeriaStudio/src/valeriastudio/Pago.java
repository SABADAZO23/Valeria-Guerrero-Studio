package valeriastudio;

import java.time.LocalDate;

public class Pago {
    public static final String INGRESO = "INGRESO";
    public static final String GASTO = "GASTO";

    public static final String EFECTIVO = "EFECTIVO";
    public static final String NEQUI = "NEQUI/QR";
    public static final String TRANSFERENCIA = "TRANSFERENCIA";

    private double monto;
    private String tipo;
    private String metodoPago;
    private LocalDate fecha;
    private String descripcion;
    private Cita citaAsociada;

    public Pago() {
        this.monto = 0.0;
        this.tipo = INGRESO;
        this.metodoPago = EFECTIVO;
        this.fecha = null;
        this.descripcion = "";
        this.citaAsociada = null;
    }

    public Pago(Cita cita, String metodoPago) {
        this.monto = cita.calcularTotal();
        this.tipo = INGRESO;
        this.metodoPago = metodoPago;
        this.fecha = cita.getFecha();
        this.descripcion = "Cita de " + cita.getCliente().getNombre();
        this.citaAsociada = cita;
    }

    public Pago(double monto, String metodoPago, LocalDate fecha, String descripcion) {
        this.monto = monto;
        this.tipo = GASTO;
        this.metodoPago = metodoPago;
        this.fecha = fecha;
        this.descripcion = descripcion;
        this.citaAsociada = null;
    }

    public boolean esIngreso() {
        return tipo.equals(INGRESO);
    }

    public boolean esGasto() {
        return tipo.equals(GASTO);
    }

    public String generarRecibo() {
        return "===== VALERIA GUERRERO STUDIO =====\n"
                + "Tipo:        " + tipo + "\n"
                + "Fecha:       " + fecha + "\n"
                + "Concepto:    " + descripcion + "\n"
                + "Método:      " + metodoPago + "\n"
                + "Valor:       $" + String.format("%,.0f", monto) + "\n"
                + "===================================";
    }

    @Override
    public String toString() {
        return fecha + " | " + tipo + " | " + descripcion + " | " + metodoPago
                + " | $" + String.format("%,.0f", monto);
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Cita getCitaAsociada() {
        return citaAsociada;
    }

    public void setCitaAsociada(Cita citaAsociada) {
        this.citaAsociada = citaAsociada;
    }
}
