package valeriastudio;

import java.time.LocalDate;
import java.time.LocalTime;

public class Cita {
    public static final String CONFIRMADA = "CONFIRMADA";
    public static final String CANCELADA = "CANCELADA";
    public static final String COMPLETADA = "COMPLETADA";
    public static final String NO_LLEGO = "NO_LLEGO";

    public static final int BUFFER_MINUTOS = 30;
    public static final int MAX_TRATAMIENTOS = 5;

    private Cliente cliente;
    private TratamientoEstetico[] tratamientos;
    private int cantidadTratamientos;
    private LocalDate fecha;
    private LocalTime horaInicio;
    private LocalTime horaFin;
    private String estado;

    public Cita() {
        this.cliente = null;
        this.tratamientos = new TratamientoEstetico[MAX_TRATAMIENTOS];
        this.cantidadTratamientos = 0;
        this.fecha = null;
        this.horaInicio = null;
        this.horaFin = null;
        this.estado = CONFIRMADA;
    }

    public Cita(Cliente cliente, LocalDate fecha, LocalTime horaInicio) {
        this.cliente = cliente;
        this.tratamientos = new TratamientoEstetico[MAX_TRATAMIENTOS];
        this.cantidadTratamientos = 0;
        this.fecha = fecha;
        this.horaInicio = horaInicio;
        this.horaFin = horaInicio;
        this.estado = CONFIRMADA;
    }

    public boolean agregarServicio(TratamientoEstetico tratamiento) {
        if (cantidadTratamientos >= MAX_TRATAMIENTOS) {
            return false;
        }
        tratamientos[cantidadTratamientos] = tratamiento;
        cantidadTratamientos++;
        recalcularHoraFin();
        return true;
    }

    private void recalcularHoraFin() {
        LocalTime hora = horaInicio;
        for (int i = 0; i < cantidadTratamientos; i++) {
            hora = tratamientos[i].calcularHoraFin(hora);
        }
        horaFin = hora.plusMinutes(BUFFER_MINUTOS);
    }

    public double calcularTotal() {
        double total = 0;
        for (int i = 0; i < cantidadTratamientos; i++) {
            total += tratamientos[i].getPrecio();
        }
        return total;
    }

    public void completar() {
        if (estado.equals(CONFIRMADA)) {
            estado = COMPLETADA;
            cliente.registrarVisita(calcularTotal(), fecha);
        }
    }

    public void cancelar() {
        if (estado.equals(CONFIRMADA)) {
            estado = CANCELADA;
        }
    }

    public void registrarNoLlego() {
        if (estado.equals(CONFIRMADA)) {
            estado = NO_LLEGO;
        }
    }

    public LocalDate sugerirFechaRetoque() {
        for (int i = 0; i < cantidadTratamientos; i++) {
            if (tratamientos[i].isRequiereRetoque()) {
                return fecha.plusDays(tratamientos[i].getDiasEntreRetoques());
            }
        }
        return null;
    }

    public boolean seCruzaCon(LocalDate otraFecha, LocalTime otroInicio, LocalTime otroFin) {
        if (!fecha.equals(otraFecha) || estado.equals(CANCELADA)) {
            return false;
        }
        return otroInicio.isBefore(horaFin) && horaInicio.isBefore(otroFin);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(fecha).append(" ").append(horaInicio).append("-").append(horaFin)
          .append(" | ").append(cliente.getNombre()).append(" | ");
        for (int i = 0; i < cantidadTratamientos; i++) {
            sb.append(tratamientos[i].getNombre());
            if (i < cantidadTratamientos - 1) sb.append(" + ");
        }
        sb.append(" | $").append(String.format("%,.0f", calcularTotal()))
          .append(" | ").append(estado);
        return sb.toString();
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public TratamientoEstetico[] getTratamientos() {
        return tratamientos;
    }

    public void setTratamientos(TratamientoEstetico[] tratamientos) {
        this.tratamientos = tratamientos;
    }

    public int getCantidadTratamientos() {
        return cantidadTratamientos;
    }

    public void setCantidadTratamientos(int cantidadTratamientos) {
        this.cantidadTratamientos = cantidadTratamientos;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public LocalTime getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(LocalTime horaInicio) {
        this.horaInicio = horaInicio;
        recalcularHoraFin();
    }

    public LocalTime getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(LocalTime horaFin) {
        this.horaFin = horaFin;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
