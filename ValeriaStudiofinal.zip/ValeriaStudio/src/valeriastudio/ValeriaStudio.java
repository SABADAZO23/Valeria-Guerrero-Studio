package valeriastudio;

import java.time.LocalDate;
import java.time.LocalTime;

public class ValeriaStudio {
    private static final int DIAS_RETOQUE_PESTANAS = 15;

    public static void cargarCatalogo(Negocio negocio) {
        negocio.agregarTratamiento(new TratamientoEstetico("Tecno clásicas", "PESTAÑAS", 110000, 120, DIAS_RETOQUE_PESTANAS));
        negocio.agregarTratamiento(new TratamientoEstetico("Tecnorimel", "PESTAÑAS", 110000, 120, DIAS_RETOQUE_PESTANAS));
        negocio.agregarTratamiento(new TratamientoEstetico("Volumen tecnológico 3D", "PESTAÑAS", 115000, 150, DIAS_RETOQUE_PESTANAS));
        negocio.agregarTratamiento(new TratamientoEstetico("Volumen tecnológico 4D", "PESTAÑAS", 120000, 150, DIAS_RETOQUE_PESTANAS));
        negocio.agregarTratamiento(new TratamientoEstetico("Volumen tecnológico 5D", "PESTAÑAS", 120000, 150, DIAS_RETOQUE_PESTANAS));

        negocio.agregarTratamiento(new TratamientoEstetico("Retoque Tecno clásicas", "PESTAÑAS", 70000, 90, DIAS_RETOQUE_PESTANAS));
        negocio.agregarTratamiento(new TratamientoEstetico("Retoque Tecnorimel", "PESTAÑAS", 70000, 90, DIAS_RETOQUE_PESTANAS));
        negocio.agregarTratamiento(new TratamientoEstetico("Retoque Volumen 3D", "PESTAÑAS", 75000, 90, DIAS_RETOQUE_PESTANAS));

        negocio.agregarTratamiento(new TratamientoEstetico("Lifting de pestañas", "PESTAÑAS", 90000, 60));
        negocio.agregarTratamiento(new TratamientoEstetico("Retiro de pestañas", "PESTAÑAS", 15000, 20));
        negocio.agregarTratamiento(new TratamientoEstetico("Laminado de cejas", "CEJAS", 85000, 60));
        negocio.agregarTratamiento(new TratamientoEstetico("Diseño de cejas en henna", "CEJAS", 40000, 45));
        negocio.agregarTratamiento(new TratamientoEstetico("Epilación de bozo", "ROSTRO", 10000, 15));

        TratamientoEstetico semipermanente = new TratamientoEstetico();
        semipermanente.setNombre("Semipermanente");
        semipermanente.setTipo("UÑAS");
        semipermanente.setPrecio(50000);
        semipermanente.setDuracionMinutos(90);
        negocio.agregarTratamiento(semipermanente);

        negocio.agregarTratamiento(new TratamientoEstetico("Soft gel", "UÑAS", 80000, 120));
        negocio.agregarTratamiento(new TratamientoEstetico("Acrílicas", "UÑAS", 100000, 150));
    }

    public static void main(String[] args) {
        Negocio negocio = new Negocio("Valeria Guerrero Studio", "Valeria Guerrero", 100, 50, 500, 500);

        cargarCatalogo(negocio);
        negocio.mostrarCatalogo();

        TratamientoEstetico pestanas = negocio.buscarTratamiento("Tecno clásicas");
        TratamientoEstetico cejas = negocio.buscarTratamiento("Diseño de cejas en henna");
        TratamientoEstetico semi = negocio.buscarTratamiento("Semipermanente");
        TratamientoEstetico softGel = negocio.buscarTratamiento("Soft gel");

        Cliente laura = new Cliente("Laura", "3001234567", LocalDate.of(2001, 5, 14), "TikTok", "Piel sensible");
        Cliente camila = new Cliente();
        camila.setNombre("Camila");
        camila.setCelular("3109876543");
        camila.setComoConocioNegocio("Recomendación");
        negocio.agregarCliente(laura);
        negocio.agregarCliente(camila);

        LocalDate hoy = LocalDate.of(2026, 10, 23);
        Cita cita1 = new Cita(laura, hoy, LocalTime.of(9, 0));
        cita1.agregarServicio(pestanas);
        cita1.agregarServicio(cejas);

        Cita cita2 = new Cita(camila, hoy, LocalTime.of(10, 0));
        cita2.agregarServicio(semi);

        System.out.println();
        System.out.println("¿Se agendó cita 1? " + negocio.agendarCita(cita1));
        System.out.println("¿Se agendó cita 2 a las 10:00? " + negocio.agendarCita(cita2));
        cita2.setHoraInicio(LocalTime.of(14, 0));
        System.out.println("¿Se agendó cita 2 a las 14:00? " + negocio.agendarCita(cita2));

        Cita cita3 = new Cita(camila, hoy.plusDays(1), LocalTime.of(9, 0));
        cita3.agregarServicio(softGel);
        negocio.agendarCita(cita3);

        System.out.println();
        negocio.consultarAgenda(hoy);

        System.out.println();
        negocio.mostrarRecordatorios(hoy);

        negocio.completarCitaYCobrar(cita1, Pago.NEQUI);
        cita2.registrarNoLlego();
        negocio.registrarGasto(35000, Pago.EFECTIVO, hoy, "Compra de esmaltes");

        System.out.println();
        System.out.println(negocio.getPagos()[0].generarRecibo());

        LocalDate retoque = cita1.sugerirFechaRetoque();
        if (retoque != null) {
            System.out.println("Sugerir retoque a " + laura.getNombre() + " para el " + retoque);
        }

        System.out.println();
        System.out.println("Perfil: " + laura);
        System.out.println();
        negocio.mostrarResumenFinanciero();
    }
}
